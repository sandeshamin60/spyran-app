import {BrowserRouter,Route} from 'react-router-dom' 
import Login from './components/Login-Page/Login'
import Forgot from './components/Login-Page/Forgot'
import Otp from './components/Login-Page/Otp'
import Reset from './components/Login-Page/Reset'
import Navbar from './components/Navbar'
import Dashboard from './components/Dashboard'
import Orders from './components/Orders'
import InProcess from './components/InProcess'
import PendingHandover from './components/PendingHandover'
import InTransist from './components/InTransist'
import ReadyToPickup from './components/ReadyToPickup'
import LastDay from './components/LastDay'
import './style.css'
import './App.css'
import './custom.css'
import './bootstrap.min.css'
// import './blue.css'
import './c3.min.css'
import './chartist-init.css'
import './chartist-plugin-tooltip.css'
import './chartist.min.css'
import './daterangepicker.css'
import './flag-icon.min.css'
import './flag-icon.min.css'
import './font-awesome.min.css'
import './fontawesome-webfont.eot'
import './fontawesome-webfont.svg'
import './fontawesome-webfont.ttf'
import './fontawesome-webfont.woff'
import './fontawesome-webfont.woff2'
import './FontAwesome.otf'
import '@fortawesome/fontawesome-free'
import '@fortawesome/fontawesome-svg-core'
import '@fortawesome/react-fontawesome'

const App=()=> {

  return (
   <BrowserRouter>
          
      <Route path='/' exact render={()=>(
         <>
        <Login/>
       </>
      )}/>
      <Route path='/dashboard' exact render={()=>(
          <>
          <Navbar/>
          <Dashboard/>
          </>
        )}/>
        <Route path='/orders' exact render={()=>(
         <> 
         <Navbar/>
         <Orders/>
         </>
        )}/>
        <Route path='/inProcess' exact render={()=>(
        <>
        <Navbar/>
        <InProcess/>
        </>
        )}/>
        <Route path='/pendingHandover' exact render={()=>(
          <>
          <Navbar/>
          <PendingHandover/>
          </>
        )}/>
        <Route path='/inTransit' exact render={()=>(
        <>
        <Navbar/>
        <InTransist/>
        </>
        )}/>
        <Route path='/readyPickup' exact render={()=>(
        <>
        <Navbar/>
        <ReadyToPickup/>
        </>
        )}/>
        <Route path='/30days' exact render={()=>(
        <>
        <Navbar/>
        <LastDay/>
        </>
        )}/>
      <Route path='/forgot' exact render={()=>(
         <>
        <Forgot/>
         </>
      )}/>
      <Route path='/otp' exact render={()=>(
        <>
        <Otp/>
        </>
      )}/>
    <Route path='/reset' component={Reset}/>
     
    </BrowserRouter>
  );
}

export default App;