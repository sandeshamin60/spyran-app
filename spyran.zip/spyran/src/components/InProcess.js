import {useState} from 'react'

const InProcess = () => {
    const [lists]=useState([
        {
            id:11,
            title:'Order ID',
            Orders:'123456789',
            Name:'Mahesh Patel',
            Mob:'+91 7878454512',
            Units:'13 Units',
            Delivery:'Express',
            Amount:1560
        },
        {
            id:12,
            title:'Customer Details',
            Orders:'123456789',
            Name:'Mahesh Patel',
            Mob:'+91 7878454512',
            Units:'13 Units',
            Delivery:'Express',
            Amount:1560
        },
        {
            id:13,
            title:'Total Product',
            Orders:'123456789',
            Name:'Mahesh Patel',
            Mob:'+91 7878454512',
            Units:'13 Units',
            Delivery:'Express',
            Amount:1560
        },
        {
            id:15,
            title:'Delivery Slot',
            Orders:'123456789',
            Name:'Mahesh Patel',
            Mob:'+91 7878454512',
            Units:'13 Units',
            Delivery:'Express',
            Amount:1560
        }
        ,
        {
            id:16,
            title:'Bill Amount',
            Orders:'123456789',
            Name:'Mahesh Patel',
            Mob:'+91 7878454512',
            Units:'13 Units',
            Delivery:'Express',
            Amount:1560
        }
        ,
        {
            id:17,
            title:'Action',
            Orders:'123456789',
            Name:'Mahesh Patel',
            Mob:'+91 7878454512',
            Units:'13 Units',
            Delivery:'Express',
            Amount:1560
        }
    ])

    return (
        <body className="fix-header fix-sidebar card-no-border">
     <div id="main-wrapper">    
         	 
         <div className="page-wrapper">             
             <div className="container">                 
                 <div className="row pt-3">
                     <div className="col-md-5 col-5 align-self-center ">
                         <h3 className="text-themecolor pagetitle">Orders </h3>                         
                     </div>
                     <div className="col-md-7 col-7 align-self-center">
					 	<div className="d-flex">
							<ol className="breadcrumb ml-auto">
								 <li className="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
								 <li className="breadcrumb-item active">Orders</li>
							 </ol>
						 </div>						 
						
                     </div>
                 </div>
				 
                
				<div className="card">					 
					 
					 <div className="card-block">
					 	<div className="">
							<div className="information-content row mb-3">
								<div className="col-lg-2 col-md-3 col-sm-6">
									<a href="/orders" className="colored-box " style={{textDecoration:'none'}}>
										<h3>02</h3>	
										<p>Pending to Process</p>									
									</a>								
                                    </div>
								<div className="col-lg-2 col-md-3 col-sm-6">
									<a href="/inProcess" className="colored-box box-yellow active" style={{textDecoration:'none'}}>
										<h3>02</h3>	
										<p>In Process</p>									
									</a>								</div>
								<div className="col-lg-2 col-md-3 col-sm-6">
									<a href="/pendingHandover" className="colored-box box-orange" style={{textDecoration:'none'}}>										
										<h3>02</h3>
										<p>Pending to handover</p>
									</a>								</div>
								<div className="col-lg-2 col-md-3 col-sm-6">
									<a href="/inTransit" className="colored-box box-indigo" style={{textDecoration:'none'}}>										
										<h3>02</h3>
										<p>In Transit</p>
									</a>								</div>		
								<div className="col-lg-2 col-md-3 col-sm-6">
									<a href="/readyPickup" className="colored-box box-green" style={{textDecoration:'none'}}>										
										<h3>02</h3>
										<p>Ready to pickup</p>
									</a>								
									</div>
								<div className="col-lg-2 col-md-3 col-sm-6">
									<a href="/30days" className="colored-box box-blue" style={{textDecoration:'none'}}>										
										<h3>02</h3>
										<p>In last 30 Days</p>
									</a>								
									</div>					
							</div>
							<button className="btn btn-info btn-md theme-btn mr-2" type="submit">Mark ad Pending to Handover</button>
						</div>
											 					
						 <div className="table-responsive pt-3">
							 <table className="table product-overview">
								 <thead className="thead-dark">
									 <tr>
										 {lists.map((items)=>(
                                             <th key={items.id}>{items.title}</th>
                                         ))}
									 </tr>
								 </thead>
								 <tbody>
								 	 <tr>
									 	<td colspan="6" className="bg-gray">
											<table>
												<tbody>
													<tr>
														<td className="border-0 p-0">
															<div className="procesby"> <span className="mr-4">Proces By: Immedealty</span>  <span>Delivery Slot: Express</span> </div>														
															</td>	
													</tr>
												</tbody>
											</table>										
										</td>
									 </tr>
								 	{lists.map((items)=>(
									 <tr>
										 <td>
										 	<div className="checkbox-demo">
												 <input type="checkbox" id="checkmark1" className="filled-in chk-col-red"/>
												 <label htmlFor="checkmark1" className="nofloting" key={items.id}>{items.Orders}</label>
											 </div>										 
											</td>
										 <td>
											 <p className="mb-0" key={items.id}>{items.Name}</p>	
											 <p className="mb-0" key={items.id}>{items.Mob}</p>										 
											</td>
										 <td key={items.id}>{items.Units}</td>
										 <td key={items.id}>{items.Delivery}</td>
										 <td key={items.id}><small className="fa fa-inr"></small>{items.Amount}</td>
										 <td>
										 	<a href="javascript:void(0)" className="p-r-10" data-toggle="tooltip" title="" data-original-title="Print"><i className="fa fa-print"></i></a>  
											<a href="order-details.html" className="" title="" data-toggle="tooltip" data-original-title="View"><i className="fa fa-pencil-square-o"></i></a>										 
										</td>
									 </tr>
                                      ))}
									 
									 
									 <tr>
									 	<td colspan="6" className="bg-gray">
											<table>
												<tbody>
													<tr>
														<td className="border-0 p-0">
															<div className="procesby"> <span className="mr-4">Proces By: Immedealty</span>  <span>Delivery Slot: Today, 02:00 PM to 03:00 PM</span> </div>														
														</td>	
													</tr>
												</tbody>
											</table>										
										</td>
									 </tr>

									{lists.map((items)=>(
									 <tr>
										 <td>
										 	<div className="checkbox-demo">
												 <input type="checkbox" id="checkmark3" className="filled-in chk-col-red"/>
												 <label htmlFor="checkmark3" className="nofloting">{items.Orders}</label>
											 </div>										 </td>
										 <td>
											 <p className="mb-0" key={items.id}>{items.Name}</p>	
											 <p className="mb-0" key={items.id}>{items.Mob}</p>										 
                                             </td>
										 <td key={items.id}>{items.Units}</td>
										 <td key={items.id}>{items.Delivery}</td>
										 <td key={items.id}><small className="fa fa-inr"></small>{items.Amount}</td>
										 <td>
										 	<a href="javascript:void(0)" className="p-r-10" data-toggle="tooltip" title="" data-original-title="Print"><i className="fa fa-print"></i></a>  
											<a href="order-details.html" className="" title="" data-toggle="tooltip" data-original-title="View"><i className="fa fa-pencil-square-o"></i></a>										 
											</td>
									 </tr>
									 ))}
								 </tbody>
							 </table>
						 </div>
					 </div>
				 </div>
             </div>
             
             <footer className="footer text-center"> Copyright(C) 2021 Spyram App. All Rights Reserved. </footer>
         </div>
     </div>
</body>
    )
}

export default InProcess
