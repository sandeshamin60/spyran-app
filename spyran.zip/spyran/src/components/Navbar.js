import logo from '../images/logo.png'
import dashboard from '../images/dashboard.png'
import orders from '../images/orders.png'
import pricingInventory from '../images/pricing_Inventory.png'
import cashCollection from '../images/cash_collection.png'
import reports from '../images/reports.png'
import shop from '../images/shop.png'

const Navbar = () => {
    return (
        <div style={{backgroundColor:'red'}}>
 <body className="fix-header fix-sidebar card-no-border"> 
 <div id="main-wrapper">    
     <header className="topbar">
         <div className="container"> 
         <nav className="navbar top-navbar navbar-toggleable-sm navbar-light">               
             <div className="navbar-header">
                 <a className="navbar-brand" href="/dashboard"><img src={logo} alt="Ever Guard" className="dark-logo" /> </a>				 
                 </div>
             
             <div className="">
                <nav className="navbar top-navbar navbar-toggleable-sm navbar-light">
                    <ul className="navbar-nav my-lg-0">
                        <li className="nav-item noarrowdrop"><a className="nav-link dropdown-toggle waves-effect waves-dark active" href="/dashboard"> <img src={dashboard} alt="icon"/> <span>Dashboard</span></a></li> 
                        <li className="nav-item noarrowdrop"><a className="nav-link dropdown-toggle waves-effect waves-dark" href="/orders"> <img src={orders} alt="icon"/> <span>Orders</span></a></li> 	
                        <li className="nav-item noarrowdrop"><a className="nav-link dropdown-toggle waves-effect waves-dark" href="price-inventory.html"> <img src={pricingInventory} alt="icon"/> <span>Price & Inventory</span></a></li> 
                        <li className="nav-item noarrowdrop"><a className="nav-link dropdown-toggle waves-effect waves-dark" href="cash-collection.html"> <img src={cashCollection} alt="icon"/> <span>Cash Collection</span></a></li> 
                        <li className="nav-item noarrowdrop"><a className="nav-link dropdown-toggle waves-effect waves-dark" href="reports.html"> <img src={reports} alt="icon"/> <span>Reports</span></a></li> 								
                    </ul>
                </nav>
             </div>
            
             <div className="navbar-collapse ml-auto" id="navwid">                  
                 <ul className="navbar-nav mr-auto mt-md-0">
                     <li className="nav-item"><a className="nav-link nav-toggler hidden-md-up" href="javascript:void(0)"><i className="fa fa-bars"></i></a>  </li>                       
                 </ul>

                 <ul className="navbar-nav my-lg-0 topmenu-content">                        
                     <li className="nav-item dropdown noarrowdrop">
                         <a className="nav-link dropdown-toggle waves-effect waves-dark" href="index.html" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">  <i className="fa fa-bell-o"></i>
                             <div className="notify"> <span className="point"></span>  </div>
                         </a>
                         <div className="dropdown-menu dropdown-menu-right mailbox scale-up">
                             <ul>
                                 <li>
                                     <div className="drop-title">Notifications </div>
                                 </li>
                                 <li>
                                     <div className="message-center">
                                         <a href="#" className="d-flex">                                                 
                                             <div className="mail-contnet">
                                                   <h5>Luanch Admin </h5>  <span className="mail-desc">Just see the my  admin! </span>												 </div>
                                             <div className="ml-auto"> <small className="time text-muted">9:30 AM </small> </div>
                                         </a>
                                         <a href="#" className="d-flex">   
                                             <div className="mail-contnet">
                                                  <h5>Event today </h5>  <span className="mail-desc">Just a reminder that  have event </span>												 
                                                  </div>
                                             <div className="ml-auto"> <small className="time text-muted">9:10 AM </small> </div>
                                         </a>
                                         <a href="#" className="d-flex">
                                             <div className="mail-contnet">
                                                  <h5>Pavan kumar </h5>  <span className="mail-desc">You can customize this  as you want </span>												 
                                                  </div>
                                             <div className="ml-auto"> <small className="time text-muted">9:08 AM </small> </div>												
                                         </a>
                                         <a href="#" className="d-flex">   
                                             <div className="mail-contnet">
                                                  <h5>Event today </h5>  <span className="mail-desc">Just a reminder that  have event </span>												 
                                                  </div>
                                             <div className="ml-auto"> <small className="time text-muted">9:10 AM </small> </div>
                                         </a>	
                                         <a href="#" className="d-flex">   
                                             <div className="mail-contnet">
                                                  <h5>Event today </h5>  <span className="mail-desc">Just a reminder that  have event </span>												 
                                                  </div>
                                             <div className="ml-auto"> <small className="time text-muted">9:10 AM </small> 
                                             </div>
                                         </a>										
                                         </div>
                                 </li>
                                 <li>
                                     <a className="nav-link text-center" href="javascript:void(0);"> <strong>Check all notifications </strong>  <i className="fa fa-angle-right"></i>  </a>                                     
                                     </li>
                             </ul>
                         </div>
                     </li>                        
                     <li className="nav-item dropdown">
                         <a className="nav-link dropdown-toggle waves-effect waves-dark" href="index.html" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src={shop} alt="shop" className="profile-pic" />   <sapn className="d-none d-lg-inline-block">Manjalpur Store</sapn></a>
                         <div className="dropdown-menu dropdown-menu-right scale-up">
                             <ul className="dropdown-user">
                                
                                 <li><a href="my-profile.html"> Store Profile </a></li>
                                 <li role="separator" className="divider"></li>
                                 <li><a href="#"><i className="fa fa-power-off"></i> Logout </a></li>
                             </ul>
                         </div>
                     </li>                         
                 </ul>
             </div>
         </nav>
        </div> 
     </header> 
     
     <aside className="left-sidebar">
             <div className="scroll-sidebar">
                 <nav className="sidebar-nav">
                     <ul id="sidebarnav">
                         <li><a href="dashboard.html"><span className="hide-menu"> Dashboard  </span></a></li>
						 <li><a href="orders.html"><span className="hide-menu"> Orders  </span></a></li>
						 <li><a href="price-inventory.html"><span className="hide-menu"> Price & Inventory  </span></a></li>
						 <li><a href="cash-collection.html"><span className="hide-menu"> Cash Collection </span></a></li>
						 <li><a href="reports.html"><span className="hide-menu"> Reports </span></a></li>						 
                     </ul>
                 </nav>
             </div> 
         </aside>

</div>
</body>
</div>
    )
}

export default Navbar;
