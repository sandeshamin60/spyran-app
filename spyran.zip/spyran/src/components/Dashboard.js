import {useState} from 'react'
const Dashboard = () => {
    const [lists]=useState(
        [
            {
                id:1,
                title:'Order ID',
                Orders:'123456789',
                Name:'Mahesh Patel',
                Mob:'+91 7878454512',
                ProcessBy:'Immediately',
                Delivery:'Express',
                Mode:'Home Delivery'
            },
            {
                id:2,
                title:'Customer Details',
                Orders:'123456789',
                Name:'Mahesh Patel',
                Mob:'+91 7878454512',
                ProcessBy:'Immediately',
                Delivery:'Express',
                Mode:'Home Delivery'
            },
            {
                id:3,
                title:'Process By',
                Orders:'123456789',
                Name:'Mahesh Patel',
                Mob:'+91 7878454512',
                ProcessBy:'Immediately',
                Delivery:'Express',
                Mode:'Home Delivery'
            },
            {
                id:4,
                title:'Delivery Slot',
                Orders:'123456789',
                Name:'Mahesh Patel',
                Mob:'+91 7878454512',
                ProcessBy:'Immediately',
                Delivery:'Express',
                Mode:'Home Delivery'
            },
            {
                id:5,
                title:'Delivery Mode',
                Orders:'123456789',
                Name:'Mahesh Patel',
                Mob:'+91 7878454512',
                ProcessBy:'Immediately',
                Delivery:'Express',
                Mode:'Home Delivery'
            },
            {
                id:6,
                title:'Action',
                Orders:'123456789',
                Name:'Mahesh Patel',
                Mob:'+91 7878454512',
                ProcessBy:'Immediately',
                Delivery:'Express',
                Mode:'Home Delivery'
            }
        ]
    );
    return (
         <body className="fix-header fix-sidebar card-no-border">

           <div className="page-wrapper">             
             <div className="container">                 
                 <div className="row pt-3">
                     <div className="col-md-5 col-5 align-self-center">
                         <h3 className="text-themecolor pagetitle">Dashboard </h3>                         
                     </div>
                     <div className="col-md-7 col-7 align-self-center">
					 	<div className="d-flex">
							<ol className="breadcrumb ml-auto">
								 <li className="breadcrumb-item"><a href="javascript:void(0)">Home </a></li>
								 <li className="breadcrumb-item active">Dashboard </li>
							 </ol>
						 </div>	
                     </div>
                 </div>
				 
				<div className="card">
					 <div className="card-header">						
						 <h4 className="card-title m-b-0 text-dark mt-3">New Orders </h4>
					 </div>
					 <div className="card-block">
					 	<div className="orders_headpart">
							<div className="d-flex align-items-center">
								<div className="titlehead_text">
									<h5 className="text-white">12</h5>
									<p className="text-white">Pending to Assign</p>
								</div>
								<div className="ml-auto">
									<a href="/orders" className="btn btn-secondary bg-white">View All <small className="fa fa-arrow-right"></small></a>								
                                    </div>
							</div>
						</div>
						
						 <div className="table-responsive pt-3">
							 <table className="table product-overview">
								 <thead>
									 <tr>
										 {lists.map((items)=>(
                                             <th key={items.id}>{items.title}</th>
                                         ))}
									 </tr>
								 </thead>

								 <tbody>
                                 {lists.map((items)=>(
                                 <tr>
                                      <td>
										 	<div className="checkbox-demo">
												 <input type="checkbox" id="checkmark1" className="filled-in chk-col-red"/>
												 <label htmlFor="checkmark1" className="nofloting" key={items.id}>{items.Orders}</label>
											 </div>										 
											</td>
										  <td>
											 <p className="mb-0" key={items.id}>{items.Name}</p>	
											 <p className="mb-0" key={items.id}>{items.Mob}</p>										 
                                             </td>
										 <td key={items.id}>{items.ProcessBy}</td>
										 <td key={items.id}>{items.Delivery} </td>
										 <td key={items.id}>{items.Mode}</td>
										 <td>
										 	<a href="javascript:void(0)" className="p-r-10" data-toggle="tooltip" title="" data-original-title="Print"><i className="fa fa-print"></i></a>  
											<a href="javascript:void(0)" className="" title="" data-toggle="tooltip" data-original-title="View"><i className="fa fa-pencil-square-o"></i></a>										 
                                            </td> 
									 </tr>
									  ))}
								 </tbody>

							 </table>
						 </div>
					 </div>
				 </div>

                 <div className="row">   
				 	 <div className="col-lg-6 col-md-6">
                         <div className="card">
                             <div className="card-block">
                                 <div className="row">
                                     <div className="col-12">
                                         <div className="d-flex flex-wrap">
                                             <h3 className="card-title">Sales Chart Category Wise</h3>                                             
                                         </div>
                                     </div>
                                     <div className="col-12">
                                         <div className="hr-mobile-scroll"><div className="amp-pxl-custom" style={{height:350}}></div></div>
                                     </div>
                                 </div>
                             </div>							 
                         </div>
                     </div>
					                  
					 <div className="col-lg-6 col-md-6">
                         <div className="card">
                             <div className="card-block">
                                 <div className="row">
                                     <div className="col-12">
                                         <div className="d-flex flex-wrap">
                                             <h3 className="card-title">Sales Chart Category Wise</h3>                                             
                                         </div>
                                     </div>
                                     <div className="col-12">                                         
										 <div id="visitor" style={{height:300,width:100}}></div>										
                                     </div>
									 
									 <div className="card-block text-center col-12 pt-0">
										 <ul className="list-inline m-b-0">
											 <li>
												 <h6 className="text-category1"><i className="fa fa-circle font-10 m-r-10 "></i>Category 1 </h6>  </li>
											 <li>
												 <h6 className="text-category2"><i className="fa fa-circle font-10 m-r-10"></i>Category 2 </h6>  </li>
											 <li>
												 <h6 className="text-category3"><i className="fa fa-circle font-10 m-r-10"></i>Category 3 </h6>  </li>
											 <li>
												 <h6 className="text-category4"><i className="fa fa-circle font-10 m-r-10"></i>Category 4 </h6>  </li>
										 </ul>
									 </div>
                                 </div>
                             </div>
                         </div>
                     </div>					                        
				 </div>	
             </div>
             <footer className="footer text-center"> Copyright(C) 2021 Spyram App. All Rights Reserved. </footer>
         </div>
         </body>
        
    )
}

export default Dashboard;
