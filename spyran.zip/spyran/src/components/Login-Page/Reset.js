import background from '../../images/login-img.jpg'
const Reset = () => {
    return (
		<section  className="login-register login-sidebar" style={{ backgroundImage:`url(${background})` }}>   
		<div className="login-box card">
	  <div className="card-block">
        <form className="form-horizontal floating-labels loginpageform" action="#">
			 <div className="form-group ">
			   <div className="col-xs-12">
				 <h2 className="text-themecolor pagetitle">Re-set new password</h2>
			   </div>
			 </div>
			 <div className="form-group input-material m-b-40">
				 <input type="password" className="form-control" id="input1" required/>
				 <span className="bar"></span>
				 <label htmlFor="input1">New password </label>
			 </div>
			 <div className="form-group input-material m-b-40">
				 <input type="password" className="form-control" id="input1" required/>
				 <span className="bar"></span>
				 <label htmlFor="input1">Confirm new password </label>
			 </div>
			 
			 <div className="form-group text-center m-t-20">
			   <div className="col-xs-12">
				 <a href="/dashboard" className="btn btn-primary btn-lg btn-block waves-effect waves-light theme-btn" type="submit">Continue </a>
			   </div>
			 </div>
		   </form>
		   </div>
		   </div>
		   </section>
    )
}

export default Reset
