import logo from '../../images/logo.png'
import background from '../../images/login-img.jpg'

const Login = () => {
    return (
        
		<section  className="login-register login-sidebar" style={{ backgroundImage:`url(${background})` }}>   
		<div className="login-box card">
	  <div className="card-block">
		   <form className="form-horizontal floating-labels loginpageform" id="">		   	 
			 <div>
                 <a href="javascript:void(0)">
                 <img src={logo} alt="Spyran"  height="100"/>
                 </a>  
                 </div>
			 	<br></br>
                 <br></br>
			 <h2 className="text-themecolor pagetitle">Login As Seller</h2>
              <br></br>
			 <div className="form-group input-material m-b-40">
				 <input className="form-control" id="input1" type="text" required/>
				 <span className="bar"></span>
				 <label htmlFor="input1">Email Address </label>
			 </div>
			 <div className="form-group input-material m-b-40">
				 <input type="password" className="form-control" id="myInput" required/>
				 <span className="bar"></span>
				 <label htmlhtmlFor="input2">Password </label>
				 <a href="javascript:void(0)" className="password-hideshow">
                 </a>
                 </div>
			 
			 <div className="form-group">
			     <div className="d-flex">
					 <div className="checkbox-demo">
						 <input type="checkbox" id="md_checkbox_21" className="filled-in chk-col-red"/>
						 <label htmlFor="md_checkbox_21" className="nofloting">Keep me logged in </label>
					 </div>	
					 <p className="ml-auto">
						<a href="/forgot" className="text-dark"><i className="fa fa-lock m-r-5"></i> Forgot Password? </a>
						 </p>  
				 </div>
			 </div>
			 <div className="form-group text-center m-t-20">
			   <div className="col-xs-12">
				 <a href="/dashboard" className="btn btn-info btn-lg btn-block theme-btn" type="submit">Login </a>
			   </div>
			 </div>
		   </form>
</div></div></section>
        
    )
    }
    

export default Login;
