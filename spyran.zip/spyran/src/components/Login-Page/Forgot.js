import background from '../../images/login-img.jpg'
const Forgot = () => {
    return (
		<section  className="login-register login-sidebar" style={{ backgroundImage:`url(${background})` }}>   
		<div className="login-box card">
	  <div className="card-block">
         <form className="form-horizontal floating-labels loginpageform" id="" action='../Navbar'>
			 <div className="form-group">
			   <div className="col-xs-12">
				 <h2 className="text-themecolor d-flex pagetitle"><span>Create a new password</span> <a href="#" className="ml-auto" id=""><i className="fa fa-arrow-left"></i>Back</a></h2>
				 <p>We'll email you a link to make a brand new password. </p>
			   </div>
			 </div>
			 <div className="form-group input-material m-b-40">
				 <input type="text" className="form-control" id="input1" required />
				 <span className="bar"></span>
				 <label htmlFor="input1">Email Address </label>
			 </div>
			 
			 <div className="form-group text-center m-t-20">
			   <div className="col-xs-12">
				 <a className="btn btn-primary btn-lg btn-block waves-effect waves-light theme-btn" type="submit" id="to-reset" href="/otp" id="to-reset">Reset </a>	
                 {/* <button href="/otp" className="btn btn-primary btn-lg btn-block waves-effect waves-light theme-btn" type="submit" id="to-reset">Reset </button>			  */}
			   </div>
			 </div>
		   </form>
		   </div></div>
		   </section>
   
)
}

export default Forgot
