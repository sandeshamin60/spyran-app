import background from '../../images/login-img.jpg'

const Otp = () => {
    return (
		<section  className="login-register login-sidebar" style={{ backgroundImage:`url(${background})` }}>   
		<div className="login-box card">
	  <div className="card-block">
        <form className="form-horizontal floating-labels loginpageform" id="" action="#">
			 <div className="form-group">
			   <div className="col-xs-12">
				 <h2 className="text-themecolor d-flex pagetitle"><span>Verify OTP</span> <a href="#" className="ml-auto" id=""><i className="fa fa-arrow-left"></i> Back</a></h2>
				 <p>OTP will received in your entered</p>
			   </div>
			 </div>
			 <div className="form-group m-b-40">
			 	<div className="d-flex otpverification_filed">
				  <input type="text" className="form-control" id="1" required/>
				  <input type="text" className="form-control" id="2" required />
				  <input type="text" className="form-control" id="3" required />
				  <input type="text" className="form-control" id="4" required />
				</div> 				
			 </div>
			 
			 <div className="form-group text-center m-t-20">
			   <div className="col-xs-12">
				 <a href="/reset" type="submit" className="btn btn-primary btn-lg btn-block waves-effect waves-light theme-btn" id="to-Verify">Reset </a>				 
			   </div>
			 </div>
		   </form>
		   </div>
		   </div>
		   </section>
    )
}

export default Otp
